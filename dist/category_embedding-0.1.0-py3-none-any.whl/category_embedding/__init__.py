from .encoder import ModernEntityEmbeddingEncoder
from .version import __version__

__all__ = ["CategoryEmbedding", "__version__"]
